package com.springboot.test.dao;

import com.springboot.test.pojo.Student;

/**
* dao
*
* @author sijie
* @date 2023/09/02 13:21
* @version 0.0.1
*/
public interface IStudentDao extends IMybatisBaseDao<Student> {
}
